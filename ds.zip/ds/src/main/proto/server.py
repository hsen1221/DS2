import grpc
from concurrent import futures
import book_pb2
import book_pb2_grpc

# temporary storage for books in memory
books_db = {}

class BookServiceServicer(book_pb2_grpc.BookServiceServicer):
    def GetBook(self, request, context):
        isbn = request.isbn
        book = books_db.get(isbn)
        if book is None:
            return book_pb2.BookResponse()  # return an empty book
        return book_pb2.BookResponse(book=book)

    def CreateBook(self, request, context):
        book = request.book
        books_db[book.isbn] = book
        return book_pb2.CreateBookResponse(success=True)

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    book_pb2_grpc.add_BookServiceServicer_to_server(BookServiceServicer(), server)
    server.add_insecure_port("[::]:50051")
    server.start()
    print("gRPC Server Running on port 50051...")
    server.wait_for_termination()

if __name__ == "__main__":
    serve()
