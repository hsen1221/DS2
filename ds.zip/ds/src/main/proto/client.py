import grpc
import book_pb2
import book_pb2_grpc

def run():
    channel = grpc.insecure_channel("localhost:50051")
    stub = book_pb2_grpc.BookServiceStub(channel)

    # add book
    new_book = book_pb2.Book(
        title="Clean Code",
        author="Robert Martin",
        isbn="9780132350884",
        year=2008
    )
    response = stub.CreateBook(book_pb2.CreateBookRequest(book=new_book))
    print("CreateBook Success:", response.success)

    # bring boook
    book_response = stub.GetBook(book_pb2.BookRequest(isbn="9780132350884"))
    print("Book Received:")
    print(book_response.book)

if __name__ == "__main__":
    run()
